﻿/// <reference path="../../typings/knockout/knockout.d.ts" />
/// <reference path="../Core/Game.ts" />
