﻿/// <reference path="../../typings/jquery/jquery.d.ts" />

module Told.AdManager {

    export class AdManager {

        minBetweenAds: number;

        constructor(minBetweenAds: number = 30) {
            this.minBetweenAds = minBetweenAds;
        }

        public showFullScreenAd(onFinished: () => void) {

        }
    }

}