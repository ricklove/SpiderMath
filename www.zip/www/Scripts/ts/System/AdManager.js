﻿/// <reference path="../../typings/jquery/jquery.d.ts" />
var Told;
(function (Told) {
    (function (_AdManager) {
        var AdManager = (function () {
            function AdManager(minBetweenAds) {
                if (typeof minBetweenAds === "undefined") { minBetweenAds = 30; }
                this.minBetweenAds = minBetweenAds;
            }
            AdManager.prototype.showFullScreenAd = function (onFinished) {
            };
            return AdManager;
        })();
        _AdManager.AdManager = AdManager;
    })(Told.AdManager || (Told.AdManager = {}));
    var AdManager = Told.AdManager;
})(Told || (Told = {}));
