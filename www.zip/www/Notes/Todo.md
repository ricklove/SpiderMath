- [x] Create Tetris style game mode
	- [x] Flip board over

- [x] Add extra blank lines on top
- [ ] Add solid line on bottom when answer wrong

