
### Examples

look
book
cook

pig
big
wig
twig

cat
hat
mat
sat

